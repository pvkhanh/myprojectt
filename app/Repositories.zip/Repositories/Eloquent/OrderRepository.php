<?php

namespace App\Repositories\Eloquent;

use App\Repositories\BaseRepository;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Models\Order;
use Illuminate\Database\Eloquent\Collection;

class OrderRepository extends BaseRepository implements OrderRepositoryInterface
{
    protected function model(): string
    {
        return Order::class;
    }

    public function getByUser(int $userId): Collection
    {
        return $this->getModel()->forUser($userId)->latest()->get();
    }

    public function getByStatus(string $status): Collection
    {
        return $this->getModel()->status($status)->latest()->get();
    }

    public function pending(): Collection
    {
        return $this->getModel()->pending()->get();
    }

    public function completed(): Collection
    {
        return $this->getModel()->completed()->get();
    }

    public function cancelled(): Collection
    {
        return $this->getModel()->cancelled()->get();
    }

    public function dateRange(string $from, string $to): Collection
    {
        return $this->getModel()->dateRange($from, $to)->get();
    }

    public function amountBetween(float $min, float $max): Collection
    {
        return $this->getModel()->amountBetween($min, $max)->get();
    }

    public function getRecentOrders(int $limit = 10): Collection
    {
        return $this->newQuery()->latest()->limit($limit)->get();
    }

    public function getRevenueByMonth(int $year): Collection
    {
        return $this->newQuery()
            ->selectRaw('MONTH(created_at) as month, SUM(total_amount) as revenue')
            ->whereYear('created_at', $year)
            ->groupBy('month')
            ->get();
    }
}
