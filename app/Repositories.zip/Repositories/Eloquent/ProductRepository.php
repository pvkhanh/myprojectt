<?php

namespace App\Repositories\Eloquent;

use App\Repositories\BaseRepository;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Models\Product;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Collection;

class ProductRepository extends BaseRepository implements ProductRepositoryInterface
{
    protected function model(): string
    {
        return Product::class;
    }

    public function getActive(): Collection
    {
        return $this->getModel()->active()->get();
    }

    public function search(string $keyword): Collection
    {
        return $this->getModel()->search($keyword)->get();
    }

    public function priceBetween(float $min, float $max): Collection
    {
        return $this->getModel()->priceBetween($min, $max)->get();
    }

    public function byCategory(int $categoryId): Collection
    {
        return $this->getModel()->categoryId($categoryId)->get();
    }

    public function hasVariants(): Collection
    {
        return $this->getModel()->hasVariants()->get();
    }

    public function searchPaginated(?string $keyword, int $perPage = 15): LengthAwarePaginator
    {
        $query = $this->newQuery();

        if ($keyword) {
            $query->search($keyword);
        }

        return $this->paginateQuery($query, $perPage);
    }

    public function findBySlug(string $slug)
    {
        return $this->newQuery()->where('slug', $slug)->first();
    }
}
