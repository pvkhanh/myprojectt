<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Models\Scopes\StockItemScopes;

class StockItem extends Model
{
    use HasFactory, SoftDeletes, StockItemScopes;

    protected $fillable = [
        'variant_id',
        'quantity',
        'location',
    ];

    protected $casts = [
        'quantity' => 'integer',
    ];
    public function variant()
    {
        return $this->belongsTo(ProductVariant::class, 'variant_id');
    }
}