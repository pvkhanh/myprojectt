<?php
namespace App\Models\Scopes;

use Illuminate\Database\Eloquent\Builder;
use App\Enums\ProductStatus;

trait ProductScopes
{
    public function scopeActive(Builder $q): Builder
    {
        return $q->where('status', ProductStatus::Active);
    }

    public function scopeSearch(Builder $q, string $keyword): Builder
    {
        return $q->where(function ($sub) use ($keyword) {
            $sub->where('name', 'LIKE', "%{$keyword}%")
                ->orWhere('description', 'LIKE', "%{$keyword}%")
                ->orWhere('slug', 'LIKE', "%{$keyword}%");
        });
    }

    public function scopePriceBetween(Builder $q, ?float $min, ?float $max): Builder
    {
        return $q->when($min !== null, fn($qq) => $qq->where('price', '>=', $min))
            ->when($max !== null, fn($qq) => $qq->where('price', '<=', $max));
    }

    public function scopeCategoryId(Builder $q, int $categoryId): Builder
    {
        return $q->whereHas('categories', fn($qq) => $qq->where('categories.id', $categoryId));
    }

    public function scopeHasVariants(Builder $q): Builder
    {
        return $q->has('variants');
    }
}
