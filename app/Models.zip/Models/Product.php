<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Enums\ProductStatus;
use App\Models\Scopes\ProductScopes;

class Product extends Model
{
    use HasFactory, SoftDeletes, ProductScopes;

    protected $fillable = [
        'name',
        'slug',
        'description',
        'price',
        'status'
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'status' => ProductStatus::class,
    ];

    public function variants()
    {
        return $this->hasMany(ProductVariant::class);
    }
    public function reviews()
    {
        return $this->hasMany(ProductReview::class);
    }
    public function cartItems()
    {
        return $this->hasMany(CartItem::class);
    }
    public function wishlists()
    {
        return $this->hasMany(Wishlist::class);
    }
    public function orders()
    {
        return $this->belongsToMany(Order::class, 'order_items');
    }
    public function categories()
    {
        return $this->morphToMany(Category::class, 'categoryable');
    }
    public function images()
    {
        return $this->morphMany(Image::class, 'imageable')->orderForDisplay();
    }

    public function primaryImage()
    {
        return $this->morphOne(Image::class, 'imageable')->primary();
    }

}
